import React from "react";
import { NewNoteInput } from "./NewNoteInput";
import { useSelector, useDispatch } from "react-redux";
import {NotesState} from "./notesReducer";
import {addNote} from "./actions";


function App() {
const notes = useSelector<NotesState, NotesState["notes"]> (
  (state) => state.notes
);
const dispatch = useDispatch();

const onAddNote = (note : string ) => {
  dispatch(addNote(note));
};



  return (
  <>
  <NewNoteInput addNote= {onAddNote} />

  <h1>
  {notes.map((note) => {
    return <h2> {note} </h2>;
  })}
  </h1>
  </>
  );
}

export default App;
