import * as React from "react";


interface Props {
  userName : string;

}


export const PropsComponent = (props : Props) => (
  <h2> Hello User : {props.userName} </h2>
);
