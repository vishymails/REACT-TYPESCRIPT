import * as React from "react";

export const HelloComponent = () => {
  return <h2> Hello Microsoft </h2> ;
};
