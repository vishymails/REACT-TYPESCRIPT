import * as React from 'react';
import { Header, About } from './components';

export const App: React.FunctionComponent<{}> = () => {
  return (
    <div className="container-fluid">
      <Header />
      <About />
    </div>
  );
}
