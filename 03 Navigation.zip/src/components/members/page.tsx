import * as React from 'react';

export const MembersPage: React.FC<{}> = () => {
  return (
    <div className="row">
      <h2> Members Page</h2>
    </div>
  );
}
