import * as React from 'react';
import { Header } from './components';

export const App: React.FC<{}> = (props) => {
  return (
    <Header />
  );
}
