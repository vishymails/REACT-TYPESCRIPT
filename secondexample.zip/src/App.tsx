import React from 'react';
import { PropsComponent } from "./propscomponent";
import { NameEditComponent } from "./nameEdit";


export const App = () => {

  const [name, setName ] = React.useState("defaultUserName");
  const [editingName, setEditingName ] = React.useState("defaultUserName");


  const loadUserName = () => {
    setTimeout(() => {
      setName ("name is called in async way ");
      setEditingName("name is called in async way")
    }, 500);
  };

  React.useEffect(() => {
    loadUserName();
  }, []);

  const setUsernameState = () => {
    setName(editingName);
  };

  return (
    <>
    <PropsComponent userName={name} />
    <NameEditComponent
    initialUserName={name}
    editingName={editingName}
    onNameUpdated={setUsernameState}
    onEditingNameUpdated={setEditingName} />
    </>
  );
};
